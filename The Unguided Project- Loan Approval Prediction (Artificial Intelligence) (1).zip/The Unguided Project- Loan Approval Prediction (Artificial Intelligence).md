```python
import warnings
warnings.filterwarnings('ignore')
```

# Step-1 : Import the required libraries


```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
```


```python
from sklearn.metrics import ConfusionMatrixDisplay
```


```python
from sklearn.preprocessing import LabelEncoder,MinMaxScaler
```


```python
from sklearn.linear_model import  LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
```


```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
```


```python
from sklearn.feature_selection import SelectKBest
from sklearn.linear_model import SGDRegressor
from xgboost import XGBClassifier
```

# Step-2: Read the dataset


```python
df=pd.read_csv("SBAnational.csv")
```

# Step-3: Data Pre-Processing
#Data Pre-Processing
#Understanding the dataset 
#and it's features and pre-processing it according to the required dataframe for model training purposes.


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LoanNr_ChkDgt</th>
      <th>Name</th>
      <th>City</th>
      <th>State</th>
      <th>Zip</th>
      <th>Bank</th>
      <th>BankState</th>
      <th>NAICS</th>
      <th>ApprovalDate</th>
      <th>ApprovalFY</th>
      <th>...</th>
      <th>RevLineCr</th>
      <th>LowDoc</th>
      <th>ChgOffDate</th>
      <th>DisbursementDate</th>
      <th>DisbursementGross</th>
      <th>BalanceGross</th>
      <th>MIS_Status</th>
      <th>ChgOffPrinGr</th>
      <th>GrAppv</th>
      <th>SBA_Appv</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1000014003</td>
      <td>ABC HOBBYCRAFT</td>
      <td>EVANSVILLE</td>
      <td>IN</td>
      <td>47711</td>
      <td>FIFTH THIRD BANK</td>
      <td>OH</td>
      <td>451120</td>
      <td>28-Feb-97</td>
      <td>1997</td>
      <td>...</td>
      <td>N</td>
      <td>Y</td>
      <td>NaN</td>
      <td>28-Feb-99</td>
      <td>$60,000.00</td>
      <td>$0.00</td>
      <td>P I F</td>
      <td>$0.00</td>
      <td>$60,000.00</td>
      <td>$48,000.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1000024006</td>
      <td>LANDMARK BAR &amp; GRILLE (THE)</td>
      <td>NEW PARIS</td>
      <td>IN</td>
      <td>46526</td>
      <td>1ST SOURCE BANK</td>
      <td>IN</td>
      <td>722410</td>
      <td>28-Feb-97</td>
      <td>1997</td>
      <td>...</td>
      <td>N</td>
      <td>Y</td>
      <td>NaN</td>
      <td>31-May-97</td>
      <td>$40,000.00</td>
      <td>$0.00</td>
      <td>P I F</td>
      <td>$0.00</td>
      <td>$40,000.00</td>
      <td>$32,000.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1000034009</td>
      <td>WHITLOCK DDS, TODD M.</td>
      <td>BLOOMINGTON</td>
      <td>IN</td>
      <td>47401</td>
      <td>GRANT COUNTY STATE BANK</td>
      <td>IN</td>
      <td>621210</td>
      <td>28-Feb-97</td>
      <td>1997</td>
      <td>...</td>
      <td>N</td>
      <td>N</td>
      <td>NaN</td>
      <td>31-Dec-97</td>
      <td>$287,000.00</td>
      <td>$0.00</td>
      <td>P I F</td>
      <td>$0.00</td>
      <td>$287,000.00</td>
      <td>$215,250.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1000044001</td>
      <td>BIG BUCKS PAWN &amp; JEWELRY, LLC</td>
      <td>BROKEN ARROW</td>
      <td>OK</td>
      <td>74012</td>
      <td>1ST NATL BK &amp; TR CO OF BROKEN</td>
      <td>OK</td>
      <td>0</td>
      <td>28-Feb-97</td>
      <td>1997</td>
      <td>...</td>
      <td>N</td>
      <td>Y</td>
      <td>NaN</td>
      <td>30-Jun-97</td>
      <td>$35,000.00</td>
      <td>$0.00</td>
      <td>P I F</td>
      <td>$0.00</td>
      <td>$35,000.00</td>
      <td>$28,000.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1000054004</td>
      <td>ANASTASIA CONFECTIONS, INC.</td>
      <td>ORLANDO</td>
      <td>FL</td>
      <td>32801</td>
      <td>FLORIDA BUS. DEVEL CORP</td>
      <td>FL</td>
      <td>0</td>
      <td>28-Feb-97</td>
      <td>1997</td>
      <td>...</td>
      <td>N</td>
      <td>N</td>
      <td>NaN</td>
      <td>14-May-97</td>
      <td>$229,000.00</td>
      <td>$0.00</td>
      <td>P I F</td>
      <td>$0.00</td>
      <td>$229,000.00</td>
      <td>$229,000.00</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 27 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 899164 entries, 0 to 899163
    Data columns (total 27 columns):
     #   Column             Non-Null Count   Dtype  
    ---  ------             --------------   -----  
     0   LoanNr_ChkDgt      899164 non-null  int64  
     1   Name               899150 non-null  object 
     2   City               899134 non-null  object 
     3   State              899150 non-null  object 
     4   Zip                899164 non-null  int64  
     5   Bank               897605 non-null  object 
     6   BankState          897598 non-null  object 
     7   NAICS              899164 non-null  int64  
     8   ApprovalDate       899164 non-null  object 
     9   ApprovalFY         899164 non-null  object 
     10  Term               899164 non-null  int64  
     11  NoEmp              899164 non-null  int64  
     12  NewExist           899028 non-null  float64
     13  CreateJob          899164 non-null  int64  
     14  RetainedJob        899164 non-null  int64  
     15  FranchiseCode      899164 non-null  int64  
     16  UrbanRural         899164 non-null  int64  
     17  RevLineCr          894636 non-null  object 
     18  LowDoc             896582 non-null  object 
     19  ChgOffDate         162699 non-null  object 
     20  DisbursementDate   896796 non-null  object 
     21  DisbursementGross  899164 non-null  object 
     22  BalanceGross       899164 non-null  object 
     23  MIS_Status         897167 non-null  object 
     24  ChgOffPrinGr       899164 non-null  object 
     25  GrAppv             899164 non-null  object 
     26  SBA_Appv           899164 non-null  object 
    dtypes: float64(1), int64(9), object(17)
    memory usage: 185.2+ MB
    


```python
df.shape
```




    (899164, 27)




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LoanNr_ChkDgt</th>
      <th>Zip</th>
      <th>NAICS</th>
      <th>Term</th>
      <th>NoEmp</th>
      <th>NewExist</th>
      <th>CreateJob</th>
      <th>RetainedJob</th>
      <th>FranchiseCode</th>
      <th>UrbanRural</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>8.991640e+05</td>
      <td>899164.000000</td>
      <td>899164.000000</td>
      <td>899164.000000</td>
      <td>899164.000000</td>
      <td>899028.000000</td>
      <td>899164.000000</td>
      <td>899164.000000</td>
      <td>899164.000000</td>
      <td>899164.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>4.772612e+09</td>
      <td>53804.391241</td>
      <td>398660.950146</td>
      <td>110.773078</td>
      <td>11.411353</td>
      <td>1.280404</td>
      <td>8.430376</td>
      <td>10.797257</td>
      <td>2753.725933</td>
      <td>0.757748</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.538175e+09</td>
      <td>31184.159152</td>
      <td>263318.312759</td>
      <td>78.857305</td>
      <td>74.108196</td>
      <td>0.451750</td>
      <td>236.688165</td>
      <td>237.120600</td>
      <td>12758.019136</td>
      <td>0.646436</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000014e+09</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.589758e+09</td>
      <td>27587.000000</td>
      <td>235210.000000</td>
      <td>60.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.361439e+09</td>
      <td>55410.000000</td>
      <td>445310.000000</td>
      <td>84.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.904627e+09</td>
      <td>83704.000000</td>
      <td>561730.000000</td>
      <td>120.000000</td>
      <td>10.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.996003e+09</td>
      <td>99999.000000</td>
      <td>928120.000000</td>
      <td>569.000000</td>
      <td>9999.000000</td>
      <td>2.000000</td>
      <td>8800.000000</td>
      <td>9500.000000</td>
      <td>99999.000000</td>
      <td>2.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    LoanNr_ChkDgt             0
    Name                     14
    City                     30
    State                    14
    Zip                       0
    Bank                   1559
    BankState              1566
    NAICS                     0
    ApprovalDate              0
    ApprovalFY                0
    Term                      0
    NoEmp                     0
    NewExist                136
    CreateJob                 0
    RetainedJob               0
    FranchiseCode             0
    UrbanRural                0
    RevLineCr              4528
    LowDoc                 2582
    ChgOffDate           736465
    DisbursementDate       2368
    DisbursementGross         0
    BalanceGross              0
    MIS_Status             1997
    ChgOffPrinGr              0
    GrAppv                    0
    SBA_Appv                  0
    dtype: int64




```python
df.dropna(subset=['Name', 'City', 'State', 'BankState', 'NewExist','RevLineCr', 'LowDoc', 'DisbursementDate', 'MIS_Status'], inplace=True)
```


```python
df.isnull().sum()
```




    LoanNr_ChkDgt             0
    Name                      0
    City                      0
    State                     0
    Zip                       0
    Bank                      0
    BankState                 0
    NAICS                     0
    ApprovalDate              0
    ApprovalFY                0
    Term                      0
    NoEmp                     0
    NewExist                  0
    CreateJob                 0
    RetainedJob               0
    FranchiseCode             0
    UrbanRural                0
    RevLineCr                 0
    LowDoc                    0
    ChgOffDate           725369
    DisbursementDate          0
    DisbursementGross         0
    BalanceGross              0
    MIS_Status                0
    ChgOffPrinGr              0
    GrAppv                    0
    SBA_Appv                  0
    dtype: int64




```python
df.dtypes
```




    LoanNr_ChkDgt          int64
    Name                  object
    City                  object
    State                 object
    Zip                    int64
    Bank                  object
    BankState             object
    NAICS                  int64
    ApprovalDate          object
    ApprovalFY            object
    Term                   int64
    NoEmp                  int64
    NewExist             float64
    CreateJob              int64
    RetainedJob            int64
    FranchiseCode          int64
    UrbanRural             int64
    RevLineCr             object
    LowDoc                object
    ChgOffDate            object
    DisbursementDate      object
    DisbursementGross     object
    BalanceGross          object
    MIS_Status            object
    ChgOffPrinGr          object
    GrAppv                object
    SBA_Appv              object
    dtype: object




```python
df[['DisbursementGross', 'BalanceGross', 'ChgOffPrinGr', 'GrAppv', 'SBA_Appv']].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DisbursementGross</th>
      <th>BalanceGross</th>
      <th>ChgOffPrinGr</th>
      <th>GrAppv</th>
      <th>SBA_Appv</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>$60,000.00</td>
      <td>$0.00</td>
      <td>$0.00</td>
      <td>$60,000.00</td>
      <td>$48,000.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>$40,000.00</td>
      <td>$0.00</td>
      <td>$0.00</td>
      <td>$40,000.00</td>
      <td>$32,000.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>$287,000.00</td>
      <td>$0.00</td>
      <td>$0.00</td>
      <td>$287,000.00</td>
      <td>$215,250.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>$35,000.00</td>
      <td>$0.00</td>
      <td>$0.00</td>
      <td>$35,000.00</td>
      <td>$28,000.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>$229,000.00</td>
      <td>$0.00</td>
      <td>$0.00</td>
      <td>$229,000.00</td>
      <td>$229,000.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Here, we notice that the issue is because of the dollar symbol, because of which converts the int dtype column to object.

#So we remove the symbol and convert the dtype of these columns.
```


```python
df[['DisbursementGross', 'BalanceGross', 'ChgOffPrinGr', 'GrAppv', 'SBA_Appv']] = \
df[['DisbursementGross', 'BalanceGross', 'ChgOffPrinGr', 'GrAppv', 'SBA_Appv']].applymap(lambda x: x.strip().replace('$', '').replace(',', ''))
```


```python
#Here, in case of ApprovalFY, we have two dtypes: str and int

#We need to convert into int dtype, so we need to check which unique values in the column has str dtype
```


```python
df['ApprovalFY'].apply(type).value_counts()
```




    <class 'int'>    759570
    <class 'str'>    126670
    Name: ApprovalFY, dtype: int64




```python
df.ApprovalFY.unique()
```




    array([1997, 1980, 2006, 1998, 1999, 2000, 2001, 1972, 2003, 2004, 1978,
           1979, 1981, 2005, 1982, 1983, 1973, 1984, 2007, 1985, 1986, 1987,
           2008, 1988, 2009, 1989, 1991, 1990, 1974, 2010, 2011, 1992, 1993,
           2002, 2012, 2013, 1994, 2014, 1975, 1977, 1976, '2004', '1994',
           '1979', '1976', '1975', '1974', '1977', '1981', '1982', '1983',
           '1984', '1978', '1980', '1968', '1976A', '1969', '1995', '1970',
           '2005', '1996', '1971', 1996, 1971], dtype=object)




```python
#So, we notice that there are some rows which have the character 'A' along with the year.
```


```python
def clean_str(x):
    if isinstance(x, str):
        return x.replace('A', '')
    return x

df.ApprovalFY = df.ApprovalFY.apply(clean_str).astype('int64')
```


```python
df['ApprovalFY'].apply(type).value_counts()
```




    <class 'int'>    886240
    Name: ApprovalFY, dtype: int64




```python
#Further converting the columns to their appropriate dtypes.
```


```python
df = df.astype({'Zip': 'str', 'NewExist': 'int64', 'UrbanRural': 'str', 'DisbursementGross': 'float', 'BalanceGross': 'float',
                          'ChgOffPrinGr': 'float', 'GrAppv': 'float', 'SBA_Appv': 'float'})
```


```python
df.dtypes
```




    LoanNr_ChkDgt          int64
    Name                  object
    City                  object
    State                 object
    Zip                   object
    Bank                  object
    BankState             object
    NAICS                  int64
    ApprovalDate          object
    ApprovalFY             int64
    Term                   int64
    NoEmp                  int64
    NewExist               int64
    CreateJob              int64
    RetainedJob            int64
    FranchiseCode          int64
    UrbanRural            object
    RevLineCr             object
    LowDoc                object
    ChgOffDate            object
    DisbursementDate      object
    DisbursementGross    float64
    BalanceGross         float64
    MIS_Status            object
    ChgOffPrinGr         float64
    GrAppv               float64
    SBA_Appv             float64
    dtype: object




```python
df['Industry'] = df['NAICS'].astype('str').apply(lambda x: x[:2])
```


```python
#Here, according the file that was provided along with the dataset, we map the industry code with the industry name.
```


```python
df['Industry'] = df['Industry'].map({
    '11': 'Ag/For/Fish/Hunt',
    '21': 'Min/Quar/Oil_Gas_ext',
    '22': 'Utilities',
    '23': 'Construction',
    '31': 'Manufacturing',
    '32': 'Manufacturing',
    '33': 'Manufacturing',
    '42': 'Wholesale_trade',
    '44': 'Retail_trade',
    '45': 'Retail_trade',
    '48': 'Trans/Ware',
    '49': 'Trans/Ware',
    '51': 'Information',
    '52': 'Finance/Insurance',
    '53': 'RE/Rental/Lease',
    '54': 'Prof/Science/Tech',
    '55': 'Mgmt_comp',
    '56': 'Admin_sup/Waste_Mgmt_Rem',
    '61': 'Educational',
    '62': 'Healthcare/Social_assist',
    '71': 'Arts/Entertain/Rec',
    '72': 'Accom/Food_serv',
    '81': 'Other_no_pub',
    '92': 'Public_Admin'
})
```


```python
df.dropna(subset = ['Industry'], inplace = True)
```


```python
#Now, we convert the FranchiseCode column to a binary column, 
#based on if whether it is or it isn't a franchise, referring the file along with the dataset.
```


```python
df.FranchiseCode.unique()
```




    array([    1, 15100, 10656, ..., 16452, 35618, 18701], dtype=int64)




```python
df.loc[(df['FranchiseCode'] <= 1), 'IsFranchise'] = 0
df.loc[(df['FranchiseCode'] > 1), 'IsFranchise'] = 1
```


```python
df.FranchiseCode
```




    0         1
    1         1
    2         1
    5         1
    7         1
             ..
    899156    1
    899157    1
    899159    1
    899160    1
    899161    1
    Name: FranchiseCode, Length: 687973, dtype: int64




```python
#Convert the NewExist column into a binary column.
```


```python
df = df[(df['NewExist'] == 1) | (df['NewExist'] == 2)]

df.loc[(df['NewExist'] == 1), 'NewBusiness'] = 0
df.loc[(df['NewExist'] == 2), 'NewBusiness'] = 1
```


```python
df.NewExist.unique()
```




    array([2, 1], dtype=int64)




```python
df.RevLineCr.unique()
```




    array(['N', 'Y', '0', 'T', '`', ',', '1', 'C', '2', 'R', '7', 'A', '-',
           'Q'], dtype=object)




```python
df.LowDoc.unique()
```




    array(['Y', 'N', 'C', '1', 'S', 'R', 'A', '0'], dtype=object)




```python
df = df[(df.RevLineCr == 'Y') | (df.RevLineCr == 'N')]
df = df[(df.LowDoc == 'Y') | (df.LowDoc == 'N')]

df['RevLineCr'] = np.where(df['RevLineCr'] == 'N', 0, 1)
df['LowDoc'] = np.where(df['LowDoc'] == 'N', 0, 1)
```


```python
df.RevLineCr.unique()
df.LowDoc.unique()
```




    array([1, 0])




```python
#Loan Status: Paid in Full, Charged Off
```


```python
df.MIS_Status.unique()

```




    array(['P I F', 'CHGOFF'], dtype=object)




```python
df.MIS_Status.value_counts()
```




    P I F     358558
    CHGOFF     98382
    Name: MIS_Status, dtype: int64




```python
df['Default'] = np.where(df['MIS_Status'] == 'P I F', 0, 1)
df['Default'].value_counts()
```




    0    358558
    1     98382
    Name: Default, dtype: int64




```python
df[['ApprovalDate', 'DisbursementDate']] = df[['ApprovalDate', 'DisbursementDate']].apply(pd.to_datetime)
```


```python
df['DaysToDisbursement'] = df['DisbursementDate'] - df['ApprovalDate']
```


```python
df.DaysToDisbursement.info()
```

    <class 'pandas.core.series.Series'>
    Int64Index: 456940 entries, 0 to 899161
    Series name: DaysToDisbursement
    Non-Null Count   Dtype          
    --------------   -----          
    456940 non-null  timedelta64[ns]
    dtypes: timedelta64[ns](1)
    memory usage: 7.0 MB
    


```python
df['DaysToDisbursement'] = df['DaysToDisbursement'].astype('str').apply(lambda x: x[:x.index('d') - 1]).astype('int64')
```


```python

```


```python
df['DisbursementFY'] = df['DisbursementDate'].map(lambda x: x.year)
```


```python
df['StateSame'] = np.where(df['State'] == df['BankState'], 1, 0)
```


```python
df['SBA_AppvPct'] = df['SBA_Appv'] / df['GrAppv']
```


```python
df['AppvDisbursed'] = np.where(df['DisbursementGross'] == df['GrAppv'], 1, 0)
```


```python
df.dtypes
```




    LoanNr_ChkDgt                  int64
    Name                          object
    City                          object
    State                         object
    Zip                           object
    Bank                          object
    BankState                     object
    NAICS                          int64
    ApprovalDate          datetime64[ns]
    ApprovalFY                     int64
    Term                           int64
    NoEmp                          int64
    NewExist                       int64
    CreateJob                      int64
    RetainedJob                    int64
    FranchiseCode                  int64
    UrbanRural                    object
    RevLineCr                      int32
    LowDoc                         int32
    ChgOffDate                    object
    DisbursementDate      datetime64[ns]
    DisbursementGross            float64
    BalanceGross                 float64
    MIS_Status                    object
    ChgOffPrinGr                 float64
    GrAppv                       float64
    SBA_Appv                     float64
    Industry                      object
    IsFranchise                  float64
    NewBusiness                  float64
    Default                        int32
    DaysToDisbursement             int64
    DisbursementFY                 int64
    StateSame                      int32
    SBA_AppvPct                  float64
    AppvDisbursed                  int32
    dtype: object




```python
df = df.astype({'IsFranchise': 'int64', 'NewBusiness': 'int64'})
```


```python
df.dtypes
```




    LoanNr_ChkDgt                  int64
    Name                          object
    City                          object
    State                         object
    Zip                           object
    Bank                          object
    BankState                     object
    NAICS                          int64
    ApprovalDate          datetime64[ns]
    ApprovalFY                     int64
    Term                           int64
    NoEmp                          int64
    NewExist                       int64
    CreateJob                      int64
    RetainedJob                    int64
    FranchiseCode                  int64
    UrbanRural                    object
    RevLineCr                      int32
    LowDoc                         int32
    ChgOffDate                    object
    DisbursementDate      datetime64[ns]
    DisbursementGross            float64
    BalanceGross                 float64
    MIS_Status                    object
    ChgOffPrinGr                 float64
    GrAppv                       float64
    SBA_Appv                     float64
    Industry                      object
    IsFranchise                    int64
    NewBusiness                    int64
    Default                        int32
    DaysToDisbursement             int64
    DisbursementFY                 int64
    StateSame                      int32
    SBA_AppvPct                  float64
    AppvDisbursed                  int32
    dtype: object




```python
df.drop(columns=['LoanNr_ChkDgt', 'Name', 'City', 'Zip', 'Bank', 'NAICS', 'ApprovalDate', 'NewExist', 'FranchiseCode',
                      'ChgOffDate', 'DisbursementDate', 'BalanceGross', 'ChgOffPrinGr', 'SBA_Appv', 'MIS_Status'], inplace=True)
```


```python
df.isnull().sum()
```




    State                 0
    BankState             0
    ApprovalFY            0
    Term                  0
    NoEmp                 0
    CreateJob             0
    RetainedJob           0
    UrbanRural            0
    RevLineCr             0
    LowDoc                0
    DisbursementGross     0
    GrAppv                0
    Industry              0
    IsFranchise           0
    NewBusiness           0
    Default               0
    DaysToDisbursement    0
    DisbursementFY        0
    StateSame             0
    SBA_AppvPct           0
    AppvDisbursed         0
    dtype: int64




```python
df.shape
```




    (456940, 21)




```python
df.Term.unique().sum()
```




    70436




```python
df['RealEstate'] = np.where(df['Term'] >= 240, 1, 0)
```


```python
df['GreatRecession'] = np.where(((2007 <= df['DisbursementFY']) & (df['DisbursementFY'] <= 2009)) | 
                                     ((df['DisbursementFY'] < 2007) & (df['DisbursementFY'] + (df['Term']/12) >= 2007)), 1, 0)
```


```python
df.DisbursementFY.unique()
```




    array([1999, 1997, 1998, 2006, 2001, 2002, 2000, 2004, 2003, 2005, 2009,
           2007, 2008, 1996, 2010, 1995, 2012, 2011, 1984, 1986, 2013, 1987,
           1988, 1989, 1990, 2014, 1994, 1991, 1992, 1993, 2020, 2028],
          dtype=int64)




```python
df = df[df.DisbursementFY <= 2010]
```


```python
df.shape
```




    (438504, 23)




```python
#Analyzing the Data based on their dtypes
```


```python
df.describe(include = ['int', 'float', 'object'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>State</th>
      <th>BankState</th>
      <th>ApprovalFY</th>
      <th>Term</th>
      <th>NoEmp</th>
      <th>CreateJob</th>
      <th>RetainedJob</th>
      <th>UrbanRural</th>
      <th>RevLineCr</th>
      <th>LowDoc</th>
      <th>...</th>
      <th>IsFranchise</th>
      <th>NewBusiness</th>
      <th>Default</th>
      <th>DaysToDisbursement</th>
      <th>DisbursementFY</th>
      <th>StateSame</th>
      <th>SBA_AppvPct</th>
      <th>AppvDisbursed</th>
      <th>RealEstate</th>
      <th>GreatRecession</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>438504</td>
      <td>438504</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>...</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
      <td>438504.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>51</td>
      <td>53</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>CA</td>
      <td>NC</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>59171</td>
      <td>55644</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>270482</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2002.665604</td>
      <td>94.119445</td>
      <td>9.794887</td>
      <td>1.843611</td>
      <td>4.568973</td>
      <td>NaN</td>
      <td>0.418959</td>
      <td>0.057247</td>
      <td>...</td>
      <td>0.030597</td>
      <td>0.263840</td>
      <td>0.221918</td>
      <td>109.090631</td>
      <td>2002.705704</td>
      <td>0.454094</td>
      <td>0.654071</td>
      <td>0.636478</td>
      <td>0.111972</td>
      <td>0.733934</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.492623</td>
      <td>68.548785</td>
      <td>57.674184</td>
      <td>16.496650</td>
      <td>15.330176</td>
      <td>NaN</td>
      <td>0.493389</td>
      <td>0.232314</td>
      <td>...</td>
      <td>0.172224</td>
      <td>0.440714</td>
      <td>0.415537</td>
      <td>182.221498</td>
      <td>5.403909</td>
      <td>0.497889</td>
      <td>0.179932</td>
      <td>0.481014</td>
      <td>0.315332</td>
      <td>0.441900</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>1984.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-3614.000000</td>
      <td>1984.000000</td>
      <td>0.000000</td>
      <td>0.050000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>1999.000000</td>
      <td>58.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>27.000000</td>
      <td>2000.000000</td>
      <td>0.000000</td>
      <td>0.500000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2005.000000</td>
      <td>84.000000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>51.000000</td>
      <td>2005.000000</td>
      <td>0.000000</td>
      <td>0.500000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2007.000000</td>
      <td>90.000000</td>
      <td>9.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>109.000000</td>
      <td>2007.000000</td>
      <td>1.000000</td>
      <td>0.829994</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2011.000000</td>
      <td>527.000000</td>
      <td>9999.000000</td>
      <td>5621.000000</td>
      <td>4441.000000</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>4029.000000</td>
      <td>2010.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>11 rows × 23 columns</p>
</div>




```python
df['DisbursedGreaterAppv'] = np.where(df['DisbursementGross'] > df['GrAppv'], 1, 0)
```


```python
df.DisbursedGreaterAppv.unique()
```




    array([0, 1])




```python
df = df[df['DaysToDisbursement'] >= 0]

df.shape
```




    (438090, 24)




```python
df.describe(include = ['int', 'float', 'object'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>State</th>
      <th>BankState</th>
      <th>ApprovalFY</th>
      <th>Term</th>
      <th>NoEmp</th>
      <th>CreateJob</th>
      <th>RetainedJob</th>
      <th>UrbanRural</th>
      <th>RevLineCr</th>
      <th>LowDoc</th>
      <th>...</th>
      <th>NewBusiness</th>
      <th>Default</th>
      <th>DaysToDisbursement</th>
      <th>DisbursementFY</th>
      <th>StateSame</th>
      <th>SBA_AppvPct</th>
      <th>AppvDisbursed</th>
      <th>RealEstate</th>
      <th>GreatRecession</th>
      <th>DisbursedGreaterAppv</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>438090</td>
      <td>438090</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>...</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
      <td>438090.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>51</td>
      <td>53</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>CA</td>
      <td>NC</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>59121</td>
      <td>55628</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>270261</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2002.662987</td>
      <td>94.113178</td>
      <td>9.795026</td>
      <td>1.843525</td>
      <td>4.567514</td>
      <td>NaN</td>
      <td>0.419122</td>
      <td>0.057189</td>
      <td>...</td>
      <td>0.263825</td>
      <td>0.222039</td>
      <td>109.220368</td>
      <td>2002.703264</td>
      <td>0.453993</td>
      <td>0.654037</td>
      <td>0.636351</td>
      <td>0.111979</td>
      <td>0.734509</td>
      <td>0.314639</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.490509</td>
      <td>68.545279</td>
      <td>57.699074</td>
      <td>16.503378</td>
      <td>15.332166</td>
      <td>NaN</td>
      <td>0.493416</td>
      <td>0.232204</td>
      <td>...</td>
      <td>0.440706</td>
      <td>0.415618</td>
      <td>182.165509</td>
      <td>5.401641</td>
      <td>0.497879</td>
      <td>0.179937</td>
      <td>0.481050</td>
      <td>0.315341</td>
      <td>0.441595</td>
      <td>0.464372</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>1984.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1984.000000</td>
      <td>0.000000</td>
      <td>0.050000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>1999.000000</td>
      <td>58.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>27.000000</td>
      <td>2000.000000</td>
      <td>0.000000</td>
      <td>0.500000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2005.000000</td>
      <td>84.000000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>51.000000</td>
      <td>2005.000000</td>
      <td>0.000000</td>
      <td>0.500000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2007.000000</td>
      <td>90.000000</td>
      <td>9.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>109.000000</td>
      <td>2007.000000</td>
      <td>1.000000</td>
      <td>0.829500</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>2011.000000</td>
      <td>527.000000</td>
      <td>9999.000000</td>
      <td>5621.000000</td>
      <td>4441.000000</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>4029.000000</td>
      <td>2010.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>11 rows × 24 columns</p>
</div>



# Step-4 Data Visualization
#Data Visualization
#Here, the plan is to find out the correlation among the columns,
#as well as find out the trends of the column, and
#how the dataframe behaves based on the time frame, particularly the fluctuation during the Great Recession


```python
plt.figure(figsize=(20,10))
sns.heatmap(df.corr(), vmin=-1, vmax=1, cmap='GnBu', annot=True)
plt.show()
```


    
![png](output_79_0.png)
    



```python
plt.figure(figsize=(15,6))
ax = sns.histplot(df, x= df.State.astype(str), hue=df.Default.astype(str), palette='flare')
plt.title(label='Percentage of Defaulted Loans per State')
plt.ylabel('Number of Loans Given to Small Business')
plt.xticks(rotation=90,fontsize=7)
plt.show()
```


    
![png](output_80_0.png)
    



```python

```


```python
plt.figure(figsize=(15,6))
ax = sns.histplot(df, x= df.GreatRecession.astype(str) ,weights=1, hue= df.Default.astype(str), palette='flare')
plt.title(label='Percentage of Loans Defaulted During Recession')
plt.ylabel('Number of Loans Given to Small Business')
plt.xlabel('Loans During Recession (1 - Rececssion / 0 - no Recession )')
plt.xticks(rotation=90,fontsize=7)
plt.show()
```


    
![png](output_82_0.png)
    



```python
industry_group = df.groupby(['Industry'])

df_industrySum = industry_group.sum().sort_values('DisbursementGross', ascending = False)
df_industryAve = industry_group.mean().sort_values('DisbursementGross', ascending=False)

fig = plt.figure(figsize=(40,20))

ax1 = fig.add_subplot(1, 2, 1)
ax1.bar(df_industrySum.index, df_industrySum['DisbursementGross'] / 1000000000)
ax1.set_xticklabels(df_industrySum.index, rotation=30, horizontalalignment='right', fontsize=10)

ax1.set_title('Gross SBA Loan Disbursement by Industry from 1984-2010', fontsize=30)
ax1.set_xlabel('Industry', fontsize = 30)
ax1.set_ylabel('Gross Loan Disbursement (Billions)', fontsize = 30)
plt.show()
```


    
![png](output_83_0.png)
    



```python
industry_group = df.groupby(['Industry'])

df_industrySum = industry_group.sum().sort_values('DisbursementGross', ascending = False)
df_industryAve = industry_group.mean().sort_values('DisbursementGross', ascending=False)

fig = plt.figure(figsize=(40,20))
ax2 = fig.add_subplot(1, 2, 2)
ax2.bar(df_industryAve.index, df_industryAve['DisbursementGross'])
ax2.set_xticklabels(df_industryAve.index, rotation=30, horizontalalignment='right', fontsize=10)

ax2.set_title('Average SBA Loan Disbursement by Industry from 1984-2010', fontsize=30)
ax2.set_xlabel('Industry',  fontsize = 30)
ax2.set_ylabel('Average Loan Disbursement',  fontsize = 30)

plt.show()
```


    
![png](output_84_0.png)
    



```python
#We notice, that Retail Trade and Manufacturing Industries have taken more loans than any other in this time period.

#But Agriculture, Forestry, Fishing, Hunting, Mining and more have small number of loans taken,
#but the amount of loan taken in total is the most relative to the other industries.
```


```python
fig2, ax = plt.subplots(figsize = (30,15))

ax.bar(df_industryAve.index, df_industryAve['DaysToDisbursement'].sort_values(ascending=False))
ax.set_xticklabels(df_industryAve['DaysToDisbursement'].sort_values(ascending=False).index, rotation=35,
                   horizontalalignment='right', fontsize=10)

ax.set_title('Average Days to SBA Loan Disbursement by Industry from 1984-2010', fontsize=15)
ax.set_xlabel('Industry')
ax.set_ylabel('Average Days to Disbursement')

plt.show()
```


    
![png](output_86_0.png)
    



```python
#Here, we notice that the industries with the highest avg loan amount also had the highest number of 
#days to disbursement of funds.

#Agri, Forestry, Fishing, Hunting ..
```


```python

```


```python
fig3 = plt.figure(figsize=(50, 30))

ax1a = plt.subplot(2,1,1)
ax2a = plt.subplot(2,1,2)

def stacked_setup(df, col, axes, stack_col='Default'):
    data = df.groupby([col, stack_col])[col].count().unstack(stack_col)
    data.fillna(0)

    axes.bar(data.index, data[1], label='Default')
    axes.bar(data.index, data[0], bottom=data[1], label='Paid in full')

# Number of Paid in full and defaulted loans by industry
stacked_setup(df=df, col='Industry', axes=ax1a)
ax1a.set_xticklabels(df.groupby(['Industry', 'Default'])['Industry'].count().unstack('Default').index,
                     rotation=35, horizontalalignment='right', fontsize=10)

ax1a.set_title('Number of PIF/Defaulted Loans by Industry from 1984-2010', fontsize=50)
ax1a.set_xlabel('Industry')
ax1a.set_ylabel('Number of PIF/Defaulted Loans')
ax1a.legend()

# Number of Paid in full and defaulted loans by State
stacked_setup(df=df, col='State', axes=ax2a)

ax2a.set_title('Number of PIF/Defaulted Loans by State from 1984-2010', fontsize= 50)
ax2a.set_xlabel('State')
ax2a.set_ylabel('Number of PIF/Defaulted Loans')
ax2a.legend()

plt.tight_layout()
plt.show()
```


    
![png](output_89_0.png)
    



```python
def_ind = df.groupby(['Industry', 'Default'])['Industry'].count().unstack('Default')
def_ind['Def_Percent'] = def_ind[1]/(def_ind[1] + def_ind[0])

def_ind
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Default</th>
      <th>0</th>
      <th>1</th>
      <th>Def_Percent</th>
    </tr>
    <tr>
      <th>Industry</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Accom/Food_serv</th>
      <td>23936</td>
      <td>8381</td>
      <td>0.259337</td>
    </tr>
    <tr>
      <th>Admin_sup/Waste_Mgmt_Rem</th>
      <td>15774</td>
      <td>5427</td>
      <td>0.255978</td>
    </tr>
    <tr>
      <th>Ag/For/Fish/Hunt</th>
      <td>6536</td>
      <td>657</td>
      <td>0.091339</td>
    </tr>
    <tr>
      <th>Arts/Entertain/Rec</th>
      <td>6976</td>
      <td>1917</td>
      <td>0.215563</td>
    </tr>
    <tr>
      <th>Construction</th>
      <td>34999</td>
      <td>12048</td>
      <td>0.256084</td>
    </tr>
    <tr>
      <th>Educational</th>
      <td>2750</td>
      <td>1070</td>
      <td>0.280105</td>
    </tr>
    <tr>
      <th>Finance/Insurance</th>
      <td>3984</td>
      <td>2093</td>
      <td>0.344413</td>
    </tr>
    <tr>
      <th>Healthcare/Social_assist</th>
      <td>29192</td>
      <td>3571</td>
      <td>0.108995</td>
    </tr>
    <tr>
      <th>Information</th>
      <td>5222</td>
      <td>1830</td>
      <td>0.259501</td>
    </tr>
    <tr>
      <th>Manufacturing</th>
      <td>36448</td>
      <td>7281</td>
      <td>0.166503</td>
    </tr>
    <tr>
      <th>Mgmt_comp</th>
      <td>90</td>
      <td>23</td>
      <td>0.203540</td>
    </tr>
    <tr>
      <th>Min/Quar/Oil_Gas_ext</th>
      <td>1133</td>
      <td>117</td>
      <td>0.093600</td>
    </tr>
    <tr>
      <th>Other_no_pub</th>
      <td>34192</td>
      <td>9351</td>
      <td>0.214753</td>
    </tr>
    <tr>
      <th>Prof/Science/Tech</th>
      <td>37278</td>
      <td>9803</td>
      <td>0.208216</td>
    </tr>
    <tr>
      <th>Public_Admin</th>
      <td>151</td>
      <td>29</td>
      <td>0.161111</td>
    </tr>
    <tr>
      <th>RE/Rental/Lease</th>
      <td>6079</td>
      <td>3097</td>
      <td>0.337511</td>
    </tr>
    <tr>
      <th>Retail_trade</th>
      <td>59503</td>
      <td>19051</td>
      <td>0.242521</td>
    </tr>
    <tr>
      <th>Trans/Ware</th>
      <td>10016</td>
      <td>4430</td>
      <td>0.306659</td>
    </tr>
    <tr>
      <th>Utilities</th>
      <td>334</td>
      <td>79</td>
      <td>0.191283</td>
    </tr>
    <tr>
      <th>Wholesale_trade</th>
      <td>26224</td>
      <td>7018</td>
      <td>0.211118</td>
    </tr>
  </tbody>
</table>
</div>




```python
def_state = df.groupby(['State', 'Default'])['State'].count().unstack('Default')
def_state['Def_Percent'] = def_state[1]/(def_state[1] + def_state[0])

def_state
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Default</th>
      <th>0</th>
      <th>1</th>
      <th>Def_Percent</th>
    </tr>
    <tr>
      <th>State</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>AK</th>
      <td>979</td>
      <td>94</td>
      <td>0.087605</td>
    </tr>
    <tr>
      <th>AL</th>
      <td>3192</td>
      <td>805</td>
      <td>0.201401</td>
    </tr>
    <tr>
      <th>AR</th>
      <td>2414</td>
      <td>528</td>
      <td>0.179470</td>
    </tr>
    <tr>
      <th>AZ</th>
      <td>5119</td>
      <td>2473</td>
      <td>0.325738</td>
    </tr>
    <tr>
      <th>CA</th>
      <td>42983</td>
      <td>16138</td>
      <td>0.272966</td>
    </tr>
    <tr>
      <th>CO</th>
      <td>7439</td>
      <td>2349</td>
      <td>0.239988</td>
    </tr>
    <tr>
      <th>CT</th>
      <td>5328</td>
      <td>1064</td>
      <td>0.166458</td>
    </tr>
    <tr>
      <th>DC</th>
      <td>567</td>
      <td>157</td>
      <td>0.216851</td>
    </tr>
    <tr>
      <th>DE</th>
      <td>841</td>
      <td>246</td>
      <td>0.226311</td>
    </tr>
    <tr>
      <th>FL</th>
      <td>14820</td>
      <td>7587</td>
      <td>0.338600</td>
    </tr>
    <tr>
      <th>GA</th>
      <td>7080</td>
      <td>3141</td>
      <td>0.307308</td>
    </tr>
    <tr>
      <th>HI</th>
      <td>1164</td>
      <td>263</td>
      <td>0.184303</td>
    </tr>
    <tr>
      <th>IA</th>
      <td>4596</td>
      <td>568</td>
      <td>0.109992</td>
    </tr>
    <tr>
      <th>ID</th>
      <td>4046</td>
      <td>886</td>
      <td>0.179643</td>
    </tr>
    <tr>
      <th>IL</th>
      <td>11500</td>
      <td>4505</td>
      <td>0.281475</td>
    </tr>
    <tr>
      <th>IN</th>
      <td>5904</td>
      <td>1524</td>
      <td>0.205170</td>
    </tr>
    <tr>
      <th>KS</th>
      <td>4269</td>
      <td>631</td>
      <td>0.128776</td>
    </tr>
    <tr>
      <th>KY</th>
      <td>2959</td>
      <td>789</td>
      <td>0.210512</td>
    </tr>
    <tr>
      <th>LA</th>
      <td>3228</td>
      <td>775</td>
      <td>0.193605</td>
    </tr>
    <tr>
      <th>MA</th>
      <td>11812</td>
      <td>2289</td>
      <td>0.162329</td>
    </tr>
    <tr>
      <th>MD</th>
      <td>5084</td>
      <td>1431</td>
      <td>0.219647</td>
    </tr>
    <tr>
      <th>ME</th>
      <td>2502</td>
      <td>317</td>
      <td>0.112451</td>
    </tr>
    <tr>
      <th>MI</th>
      <td>7976</td>
      <td>3287</td>
      <td>0.291841</td>
    </tr>
    <tr>
      <th>MN</th>
      <td>9186</td>
      <td>1688</td>
      <td>0.155233</td>
    </tr>
    <tr>
      <th>MO</th>
      <td>7679</td>
      <td>1636</td>
      <td>0.175631</td>
    </tr>
    <tr>
      <th>MS</th>
      <td>3754</td>
      <td>677</td>
      <td>0.152787</td>
    </tr>
    <tr>
      <th>MT</th>
      <td>3533</td>
      <td>264</td>
      <td>0.069529</td>
    </tr>
    <tr>
      <th>NC</th>
      <td>4922</td>
      <td>1423</td>
      <td>0.224271</td>
    </tr>
    <tr>
      <th>ND</th>
      <td>2319</td>
      <td>174</td>
      <td>0.069795</td>
    </tr>
    <tr>
      <th>NE</th>
      <td>2329</td>
      <td>285</td>
      <td>0.109028</td>
    </tr>
    <tr>
      <th>NH</th>
      <td>5966</td>
      <td>922</td>
      <td>0.133856</td>
    </tr>
    <tr>
      <th>NJ</th>
      <td>8217</td>
      <td>3241</td>
      <td>0.282859</td>
    </tr>
    <tr>
      <th>NM</th>
      <td>2408</td>
      <td>321</td>
      <td>0.117626</td>
    </tr>
    <tr>
      <th>NV</th>
      <td>2688</td>
      <td>1239</td>
      <td>0.315508</td>
    </tr>
    <tr>
      <th>NY</th>
      <td>24822</td>
      <td>8237</td>
      <td>0.249161</td>
    </tr>
    <tr>
      <th>OH</th>
      <td>14150</td>
      <td>3592</td>
      <td>0.202457</td>
    </tr>
    <tr>
      <th>OK</th>
      <td>3839</td>
      <td>765</td>
      <td>0.166160</td>
    </tr>
    <tr>
      <th>OR</th>
      <td>4519</td>
      <td>1137</td>
      <td>0.201025</td>
    </tr>
    <tr>
      <th>PA</th>
      <td>14959</td>
      <td>3146</td>
      <td>0.173764</td>
    </tr>
    <tr>
      <th>RI</th>
      <td>4227</td>
      <td>730</td>
      <td>0.147266</td>
    </tr>
    <tr>
      <th>SC</th>
      <td>1925</td>
      <td>616</td>
      <td>0.242424</td>
    </tr>
    <tr>
      <th>SD</th>
      <td>1759</td>
      <td>132</td>
      <td>0.069804</td>
    </tr>
    <tr>
      <th>TN</th>
      <td>3477</td>
      <td>1003</td>
      <td>0.223884</td>
    </tr>
    <tr>
      <th>TX</th>
      <td>22738</td>
      <td>6203</td>
      <td>0.214333</td>
    </tr>
    <tr>
      <th>UT</th>
      <td>8565</td>
      <td>2607</td>
      <td>0.233351</td>
    </tr>
    <tr>
      <th>VA</th>
      <td>4862</td>
      <td>1371</td>
      <td>0.219958</td>
    </tr>
    <tr>
      <th>VT</th>
      <td>2222</td>
      <td>199</td>
      <td>0.082197</td>
    </tr>
    <tr>
      <th>WA</th>
      <td>9015</td>
      <td>2074</td>
      <td>0.187032</td>
    </tr>
    <tr>
      <th>WI</th>
      <td>8591</td>
      <td>1463</td>
      <td>0.145514</td>
    </tr>
    <tr>
      <th>WV</th>
      <td>1188</td>
      <td>212</td>
      <td>0.151429</td>
    </tr>
    <tr>
      <th>WY</th>
      <td>1156</td>
      <td>69</td>
      <td>0.056327</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig4, ax4 = plt.subplots(figsize = (30,15))

stack_data = df.groupby(['DisbursementFY', 'Default'])['DisbursementFY'].count().unstack('Default')

x = stack_data.index
y = [stack_data[1], stack_data[0]]

ax4.stackplot(x, y, labels = ['Default', 'Paid In Full'])
ax4.set_title('Number of PIF/Defaulted Loans by State from 1984-2010', fontsize = 30)

ax4.set_xlabel('Disbursement Year')
ax4.set_ylabel('Number of PIF/Defaulted Loans')
ax4.legend(loc='upper left', fontsize = 20)

plt.show()
```


    
![png](output_92_0.png)
    


# Step-5 Model Training and Testing
#Here, the plan is to one hot encode the dataframe, 
#Normalise the dataframe by scaling it and spliting the dataset into training and testing dataframes,
#and train the model on the training dataset and test it on the testing and comparing the prediction and 
#the testing target column using various metrics to find out the best possible model for the dataset.

#The Classifier Models to be used are:

#Logistic Regression
#Decision Tree Classifier
#Random Forest Classifier
#Naive Bayes
#Voting Classifier
#Linear Discriminant Analysis


```python
df = pd.get_dummies(df)

df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ApprovalFY</th>
      <th>Term</th>
      <th>NoEmp</th>
      <th>CreateJob</th>
      <th>RetainedJob</th>
      <th>RevLineCr</th>
      <th>LowDoc</th>
      <th>DisbursementGross</th>
      <th>GrAppv</th>
      <th>IsFranchise</th>
      <th>...</th>
      <th>Industry_Mgmt_comp</th>
      <th>Industry_Min/Quar/Oil_Gas_ext</th>
      <th>Industry_Other_no_pub</th>
      <th>Industry_Prof/Science/Tech</th>
      <th>Industry_Public_Admin</th>
      <th>Industry_RE/Rental/Lease</th>
      <th>Industry_Retail_trade</th>
      <th>Industry_Trans/Ware</th>
      <th>Industry_Utilities</th>
      <th>Industry_Wholesale_trade</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1997</td>
      <td>84</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>60000.0</td>
      <td>60000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1997</td>
      <td>60</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>40000.0</td>
      <td>40000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1997</td>
      <td>180</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>287000.0</td>
      <td>287000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1997</td>
      <td>120</td>
      <td>19</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>517000.0</td>
      <td>517000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1997</td>
      <td>84</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>45000.0</td>
      <td>45000.0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 147 columns</p>
</div>




```python
y = df['Default']
X = df.drop('Default', axis = 1)
```


```python
scale = StandardScaler()
X_scld = scale.fit_transform(X)
```


```python
X_train, X_val, y_train, y_val = train_test_split(X_scld, y, test_size=0.25,random_state = 7)
```

# Logistic Regression


```python
from sklearn.metrics import classification_report
```


```python
lr = LogisticRegression()

lr.fit(X_train, y_train)
y_pred = lr.predict(X_val)

print(classification_report(y_val, y_pred, digits = 3))
```

                  precision    recall  f1-score   support
    
               0      0.896     0.951     0.923     85341
               1      0.781     0.610     0.685     24182
    
        accuracy                          0.876    109523
       macro avg      0.838     0.781     0.804    109523
    weighted avg      0.871     0.876     0.870    109523
    
    


```python
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred, labels=lr.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=lr.classes_)
disp.plot()
```




    <sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay at 0x1f8890f8ee0>




    
![png](output_101_1.png)
    


# Decision Tree


```python
dtc = DecisionTreeClassifier()
model_dtc = dtc.fit(X_train, y_train)

y_pred = dtc.predict(X_val)

print(classification_report(y_val, y_pred, digits = 3))
```

                  precision    recall  f1-score   support
    
               0      0.958     0.955     0.957     85341
               1      0.844     0.853     0.849     24182
    
        accuracy                          0.933    109523
       macro avg      0.901     0.904     0.903    109523
    weighted avg      0.933     0.933     0.933    109523
    
    


```python
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred, labels=dtc.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=dtc.classes_)
disp.plot()
```




    <sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay at 0x1f88629a040>




    
![png](output_104_1.png)
    



```python
print("Testing accuracy is:",accuracy_score(y_val, y_pred))
```

    Testing accuracy is: 0.9327629812916008
    

# Random Forest Classifier


```python
rfc = RandomForestClassifier()
model_rfc = rfc.fit(X_train, y_train)

predictions= rfc.predict(X_val)

print(classification_report(y_val, predictions, digits = 3))
```

                  precision    recall  f1-score   support
    
               0      0.953     0.980     0.966     85341
               1      0.923     0.829     0.873     24182
    
        accuracy                          0.947    109523
       macro avg      0.938     0.905     0.920    109523
    weighted avg      0.946     0.947     0.946    109523
    
    


```python
# Confusion Matrix
cm = confusion_matrix(y_val, predictions, labels=rfc.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=rfc.classes_)
disp.plot()
```




    <sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay at 0x1f889ba71f0>




    
![png](output_108_1.png)
    



```python
print("Testing accuracy is:",accuracy_score(y_val, predictions))
```

    Testing accuracy is: 0.9469335208129799
    

# Naive Bayes 


```python
gnb = GaussianNB()
model_gnb = gnb.fit(X_train, y_train)

y_pred = gnb.predict(X_val)

print(classification_report(y_val, y_pred, digits = 3))
```

                  precision    recall  f1-score   support
    
               0      0.921     0.485     0.635     85341
               1      0.319     0.854     0.465     24182
    
        accuracy                          0.566    109523
       macro avg      0.620     0.669     0.550    109523
    weighted avg      0.788     0.566     0.597    109523
    
    


```python
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred, labels=gnb.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=gnb.classes_)
disp.plot()
```




    <sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay at 0x1f8890c5700>




    
![png](output_112_1.png)
    



```python
print("Testing Accuracy is: ", accuracy_score(y_val, y_pred))
```

    Testing Accuracy is:  0.566008966153228
    

# Support Vector Classifier


```python
model=SVC()
model_svc=model.fit(X_train, y_train)

y_pred=model.predict(X_val)

print(classification_report(y_val, y_pred, digits = 3))
```


```python
print("Testing Accuracy is: ", accuracy_score(y_val, y_pred))
```


```python
# It is taking huge amount of time to run.
```

# LinearDiscriminantAnalysis


```python
model=LinearDiscriminantAnalysis()
model_LDA=model.fit(X_train, y_train)

y_pred=model.predict(X_val)

print(classification_report(y_val, y_pred, digits = 3))
```

                  precision    recall  f1-score   support
    
               0      0.917     0.889     0.903     85341
               1      0.647     0.717     0.680     24182
    
        accuracy                          0.851    109523
       macro avg      0.782     0.803     0.792    109523
    weighted avg      0.858     0.851     0.854    109523
    
    


```python
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred, labels=model.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=model.classes_)
disp.plot()
```




    <sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay at 0x1f88a5ca9d0>




    
![png](output_120_1.png)
    



```python
print("Testing Accuracy is: ", accuracy_score(y_val, y_pred))
```

    Testing Accuracy is:  0.8511088995005616
    

# Voting Classifier


```python
from sklearn.ensemble import VotingClassifier
rfc = RandomForestClassifier(random_state=42)
dtc = DecisionTreeClassifier(random_state=42)
lr = LogisticRegression()

pipe = VotingClassifier([('dtc', dtc),('rfc', rfc),('lr', lr)], weights = [4,5,1])
```


```python
pipe.fit(X_train, y_train)
```




    VotingClassifier(estimators=[('dtc', DecisionTreeClassifier(random_state=42)),
                                 ('rfc', RandomForestClassifier(random_state=42)),
                                 ('lr', LogisticRegression())],
                     weights=[4, 5, 1])




```python
y_pred = pipe.predict(X_val)
print(classification_report(y_val, y_pred, digits = 3))
```

                  precision    recall  f1-score   support
    
               0      0.947     0.983     0.965     85341
               1      0.931     0.808     0.865     24182
    
        accuracy                          0.944    109523
       macro avg      0.939     0.895     0.915    109523
    weighted avg      0.944     0.944     0.943    109523
    
    


```python
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred, labels=pipe.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=pipe.classes_)
disp.plot()
```




    <sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay at 0x1f88a7091f0>




    
![png](output_126_1.png)
    



```python
print("Testing Accuracy is: ", accuracy_score(y_val, y_pred))
```

    Testing Accuracy is:  0.9442400226436456
    

# KNearestneighbors


```python
knn=KNeighborsClassifier()
model_knn=knn.fit(X_train, y_train)

y_pred=knn.predict(X_val)

print(classification_report(y_val, y_pred, digits = 3))
```


```python
print("Testing Accuracy is: ", accuracy_score(y_val, y_pred))
```


```python
# It is taking huge amount of time to run. But the code is correct.
```

# XGBoost model


```python
xgboost = XGBClassifier(random_state=2)

xgboost.fit(X_train, y_train)
y_xgbpred = xgboost.predict(X_val)

# Print the results
print(classification_report(y_val, y_xgbpred, digits=3))
```

                  precision    recall  f1-score   support
    
               0      0.969     0.975     0.972     85341
               1      0.909     0.890     0.899     24182
    
        accuracy                          0.956    109523
       macro avg      0.939     0.932     0.936    109523
    weighted avg      0.956     0.956     0.956    109523
    
    


```python
# List the importance of each feature
for name, importance in sorted(zip(X.columns, xgboost.feature_importances_)):
    print(name, "=", importance)
```

    ApprovalFY = 0.045704044
    AppvDisbursed = 0.014540423
    BankState_AK = 0.0
    BankState_AL = 0.005222005
    BankState_AR = 0.0031680982
    BankState_AZ = 0.001699841
    BankState_CA = 0.037348505
    BankState_CO = 0.0
    BankState_CT = 0.0021917343
    BankState_DC = 0.0
    BankState_DE = 0.027426753
    BankState_FL = 0.012294866
    BankState_GA = 0.015703663
    BankState_GU = 0.0
    BankState_HI = 0.003156208
    BankState_IA = 0.0039884574
    BankState_ID = 0.0018634342
    BankState_IL = 0.019827189
    BankState_IN = 0.007217285
    BankState_KS = 0.003562555
    BankState_KY = 0.0013092845
    BankState_LA = 0.002207146
    BankState_MA = 0.0023689298
    BankState_MD = 0.0073627625
    BankState_ME = 0.0002417015
    BankState_MI = 0.002854141
    BankState_MN = 0.0048424313
    BankState_MO = 0.0038245919
    BankState_MS = 0.006117716
    BankState_MT = 0.012076927
    BankState_NC = 0.04208473
    BankState_ND = 0.0027868114
    BankState_NE = 0.0023270708
    BankState_NH = 0.0049127545
    BankState_NJ = 0.0024666486
    BankState_NM = 0.0
    BankState_NV = 0.0017977157
    BankState_NY = 0.0039449646
    BankState_OH = 0.014690493
    BankState_OK = 0.0015397422
    BankState_OR = 0.009262986
    BankState_PA = 0.032782085
    BankState_PR = 0.0
    BankState_RI = 0.009549174
    BankState_SC = 0.0042574718
    BankState_SD = 0.0044398042
    BankState_TN = 0.002515151
    BankState_TX = 0.007392037
    BankState_UT = 0.005022431
    BankState_VA = 0.030742273
    BankState_VT = 0.008911808
    BankState_WA = 0.0010390686
    BankState_WI = 0.0019582326
    BankState_WV = 0.0015716496
    BankState_WY = 0.002253475
    CreateJob = 0.0013794521
    DaysToDisbursement = 0.0041796006
    DisbursedGreaterAppv = 0.010485705
    DisbursementFY = 0.014302064
    DisbursementGross = 0.0042576413
    GrAppv = 0.007840249
    GreatRecession = 0.010811195
    Industry_Accom/Food_serv = 0.0043567694
    Industry_Admin_sup/Waste_Mgmt_Rem = 0.0013075791
    Industry_Ag/For/Fish/Hunt = 0.0050241766
    Industry_Arts/Entertain/Rec = 0.0020607933
    Industry_Construction = 0.002216471
    Industry_Educational = 0.003091284
    Industry_Finance/Insurance = 0.00328398
    Industry_Healthcare/Social_assist = 0.015863232
    Industry_Information = 0.0009674471
    Industry_Manufacturing = 0.0015822335
    Industry_Mgmt_comp = 0.0
    Industry_Min/Quar/Oil_Gas_ext = 0.0024649522
    Industry_Other_no_pub = 0.002255089
    Industry_Prof/Science/Tech = 0.0044761007
    Industry_Public_Admin = 0.00069392455
    Industry_RE/Rental/Lease = 0.004232572
    Industry_Retail_trade = 0.004265078
    Industry_Trans/Ware = 0.0017470903
    Industry_Utilities = 0.0
    Industry_Wholesale_trade = 0.0016230674
    IsFranchise = 0.0021425567
    LowDoc = 0.008559905
    NewBusiness = 0.004126965
    NoEmp = 0.0026423389
    RealEstate = 0.0
    RetainedJob = 0.0020840783
    RevLineCr = 0.013578618
    SBA_AppvPct = 0.01689296
    StateSame = 0.06387264
    State_AK = 0.0022605497
    State_AL = 0.0017787472
    State_AR = 0.0041762134
    State_AZ = 0.0039316006
    State_CA = 0.026422372
    State_CO = 0.0021133455
    State_CT = 0.0020855675
    State_DC = 0.0032942789
    State_DE = 0.0
    State_FL = 0.008262409
    State_GA = 0.005510913
    State_HI = 0.0010907648
    State_IA = 0.004091184
    State_ID = 0.00061781215
    State_IL = 0.0068222755
    State_IN = 0.002568065
    State_KS = 0.0
    State_KY = 0.0023131617
    State_LA = 0.0036688736
    State_MA = 0.0022913967
    State_MD = 0.0034918557
    State_ME = 0.005506698
    State_MI = 0.0034648322
    State_MN = 0.0076202396
    State_MO = 0.00075791776
    State_MS = 0.001534239
    State_MT = 0.008555674
    State_NC = 0.0021552758
    State_ND = 0.0014527963
    State_NE = 0.0018793022
    State_NH = 0.0010822088
    State_NJ = 0.0027908026
    State_NM = 0.0019482715
    State_NV = 0.0045073675
    State_NY = 0.004502076
    State_OH = 0.0052066925
    State_OK = 0.0024251575
    State_OR = 0.0006147602
    State_PA = 0.007344109
    State_RI = 0.0
    State_SC = 0.004034005
    State_SD = 0.00095836556
    State_TN = 0.0036489025
    State_TX = 0.0027874794
    State_UT = 0.01366682
    State_VA = 0.0025217326
    State_VT = 0.0041471105
    State_WA = 0.004070196
    State_WI = 0.0037413572
    State_WV = 0.0
    State_WY = 0.006293211
    Term = 0.08528862
    UrbanRural_0 = 0.01990664
    UrbanRural_1 = 0.02246614
    UrbanRural_2 = 0.0012924633
    


```python
# Build pipeling for feature selection and modeling; SelectKBest defaults to top 10 features
xgb_featimp = XGBClassifier(random_state=2)

pipe = Pipeline(steps=[
    ('feature_selection', SelectKBest()),
    ('model', xgb_featimp)
])

pipe.fit(X_train, y_train)
y_featimppred = pipe.predict(X_val)

print(classification_report(y_val, y_featimppred, digits=3))
```

                  precision    recall  f1-score   support
    
               0      0.965     0.965     0.965     85341
               1      0.875     0.876     0.875     24182
    
        accuracy                          0.945    109523
       macro avg      0.920     0.920     0.920    109523
    weighted avg      0.945     0.945     0.945    109523
    
    


```python
# List the importance of each feature
for name, importance in sorted(zip(X.columns, xgb_featimp.feature_importances_)):
    print(name, "=", importance)
```

    ApprovalFY = 0.14421694
    CreateJob = 0.15028732
    DisbursementGross = 0.047627266
    GrAppv = 0.049742658
    IsFranchise = 0.07320356
    LowDoc = 0.0
    NoEmp = 0.04854698
    RetainedJob = 0.043624863
    RevLineCr = 0.037483767
    Term = 0.40526658
    

# Step-5:- Save and Load the Machine Learning Models : (2 Methods)
#--------------------------------------------------------
#This allows you to save your model to file and load it later
#in order to make predictions in future.

#Method-1) Use pickle to serialize(=dump) and deserialize(=load)
# #       machine learning models.

#Method-2) Use Joblib to serialize(=dump) and deserialize(=load)
# #       machine learning models.

# I am using Method-1)


```python
import pickle
```


```python
#save the model to disk
filename = "C://Users//Narendra Malviya//Desktop//Unguided Project//Finalized_Model.sav"
pickle.dump(model,open(filename, "wb"))     #wb= write binary

print("Model dumped successfully into a file by Pickle"
     ".....\n....\n....\n....")

print("-------------------------\n\n\n")
print("some time later....   ")
print("\n\n\n-------------------")
```

    Model dumped successfully into a file by Pickle.....
    ....
    ....
    ....
    -------------------------
    
    
    
    some time later....   
    
    
    
    -------------------
    


```python
#load the model from disk
import pickle
filename = "C://Users//Narendra Malviya//Desktop//Unguided Project//Finalized_Model.sav"
loaded_model = pickle.load(open(filename, "rb"))     #rb = reuse binary
print("Model loaded successfully from the file by Pickle")
```

    Model loaded successfully from the file by Pickle
    

# In conclusion, we get the best result from the Random Forest Classifier and XGBoost Classifier with an accuracy score of 94.6 and 94.5 on the testing dataframe respectively.

#With this project, I got to learn about the Loan Approval Process for Small Business Administration (SBA), 
#as well about the entire process from taking the loan to disbursement of it, based on the different sectors of business. 
#Also understood the effect of Great Recession 
#on the Disbursement of the loans during that period, and it's effect on taking loans.

# Submitted By:- Nimisha Malviya
The Unguided Project Of Artificial Intelligence Batch-1(18May-15June) 

# The Unguided Project Of Artificial Intelligence Batch-1(18May-15June)


```python

```
